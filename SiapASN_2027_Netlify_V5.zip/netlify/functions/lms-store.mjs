import { getStore } from "@netlify/blobs";

const STORE_NAME = "siapasn-2027-store";
const DATA_KEY = "lms-state-v5";

// Fallback in-memory/file storage if Netlify Blobs isn't initialized in a local emulator
const fallbackStore = {
  record: null
};

function getSafeStore() {
  try {
    return getStore({ name: STORE_NAME, consistency: "strong" });
  } catch (e) {
    return null;
  }
}

export default async (req, context) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }

  const store = getSafeStore();

  try {
    if (req.method === "GET") {
      let record = null;
      if (store) {
        record = await store.get(DATA_KEY, { type: "json" });
      }
      if (!record) {
        record = fallbackStore.record;
      }
      return new Response(JSON.stringify({ ok: true, record: record || null }), {
        status: 200,
        headers
      });
    }

    if (req.method === "POST") {
      const body = await req.json();
      const record = {
        users: Array.isArray(body.users) ? body.users : [],
        materi: Array.isArray(body.materi) ? body.materi : [],
        soal: Array.isArray(body.soal) ? body.soal : [],
        completedMateriMap:
          body.completedMateriMap && typeof body.completedMateriMap === "object"
            ? body.completedMateriMap
            : {},
        catHistoryMap:
          body.catHistoryMap && typeof body.catHistoryMap === "object"
            ? body.catHistoryMap
            : {},
        updatedAt: new Date().toISOString()
      };

      if (store) {
        await store.setJSON(DATA_KEY, record);
      }
      fallbackStore.record = record;

      return new Response(JSON.stringify({ ok: true, record }), {
        status: 200,
        headers
      });
    }

    return new Response(JSON.stringify({ ok: false, error: "Method not allowed" }), {
      status: 405,
      headers
    });
  } catch (err) {
    return new Response(
      JSON.stringify({
        ok: false,
        error: err && err.message ? err.message : "Internal server error"
      }),
      { status: 500, headers }
    );
  }
};
